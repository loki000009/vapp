import 'dart:io';
import 'dart:convert';
import '../models/analysis_model.dart';
import '../services/file_service.dart';

class AnalysisService {
  Future<DataAnalysis?> analyzeFile(String filePath) async {
    try {
      final fileService = FileService();
      final data = await fileService.importData();

      // Convert data to JSON string for input
      final dataJson = jsonEncode(data);

      // 1. Start the Python app process
      final process = await Process.start(
        '/path/to/your/python_app.apk', // Replace with the actual path to your Python APK
        [], // Arguments (you might pass the dataJson here, or use stdin)
        // environment: {}, // If you need to set any environment variables
        // workingDirectory: '', // If your Python app expects a specific working directory
      );

      // 2. Send input data to the Python app (if not using arguments)
      // process.stdin.writeln(dataJson);
      // await process.stdin.flush();
      // await process.stdin.close();

      // 3. Read output from the Python app
      String resultString = '';
      await process.stdout.transform(utf8.decoder).forEach((line) {
        resultString += line;
      });

      // 4. Get the exit code (check for errors)
      final exitCode = await process.exitCode;
      if (exitCode != 0) {
        throw Exception('Python app exited with error code: $exitCode');
      }

      // 5. Parse the result (assuming it's JSON)
      final analysisResult = jsonDecode(resultString);

      return DataAnalysis.fromJson(analysisResult);
    } catch (e) {
      print('Error analyzing data: $e');
      return null;
    }
  }
}