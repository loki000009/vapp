import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/data_model.dart';
import '../services/file_service.dart';
import '../widgets/chart_widgets.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/rendering.dart';
import 'dart:typed_data';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final FileService _fileService = FileService();
  String _selectedChartType = 'line';
  String _selectedXAxis = '';
  String _selectedYAxis = '';
  final GlobalKey _chartKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Visualization Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.file_upload),
            onPressed: _importData,
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: () => _exportData(context),
          ),
          IconButton(
            icon: const Icon(Icons.photo),
            onPressed: () => _saveChartAsImage(context),
          ),
        ],
      ),
      body: Consumer<DataSet>(
        builder: (context, dataSet, child) {
          if (dataSet.data.isEmpty) {
            return const Center(
              child: Text('Import data to begin visualization'),
            );
          }

          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  _buildChartControls(dataSet),
                  const SizedBox(height: 20),
                  RepaintBoundary(
                    key: _chartKey,
                    child: _buildChart(dataSet),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildChartControls(DataSet dataSet) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Chart Type'),
              value: _selectedChartType,
              items: const [
                DropdownMenuItem(value: 'line', child: Text('Line Chart')),
                DropdownMenuItem(value: 'bar', child: Text('Bar Chart')),
                DropdownMenuItem(value: 'pie', child: Text('Pie Chart')),
              ],
              onChanged: (value) {
                setState(() {
                  _selectedChartType = value ?? 'line';
                });
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'X Axis'),
              value: _selectedXAxis.isEmpty ? dataSet.columns.first : _selectedXAxis,
              items: dataSet.columns
                  .map((column) => DropdownMenuItem(
                        value: column,
                        child: Text(column),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedXAxis = value ?? dataSet.columns.first;
                });
              },
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Y Axis'),
              value: _selectedYAxis.isEmpty ? dataSet.columns.last : _selectedYAxis,
              items: dataSet.columns
                  .map((column) => DropdownMenuItem(
                        value: column,
                        child: Text(column),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedYAxis = value ?? dataSet.columns.last;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChart(DataSet dataSet) {
    if (_selectedXAxis.isEmpty || _selectedYAxis.isEmpty) {
      _selectedXAxis = dataSet.columns.first;
      _selectedYAxis = dataSet.columns.last;
    }

    switch (_selectedChartType) {
      case 'line':
        return ChartWidgets.lineChart(
          dataSet.data,
          _selectedXAxis,
          _selectedYAxis,
        );
      case 'bar':
        return ChartWidgets.barChart(
          dataSet.data,
          _selectedXAxis,
          _selectedYAxis,
        );
      case 'pie':
        return ChartWidgets.pieChart(
          dataSet.data,
          _selectedXAxis,
          _selectedYAxis,
        );
      default:
        return const SizedBox.shrink();
    }
  }

  Future<void> _importData() async {
    final data = await _fileService.importData();
    if (data.isNotEmpty && mounted) {
      context.read<DataSet>().updateData(data, 'Imported Dataset');
    }
  }

  Future<void> _exportData(BuildContext parentContext) async {
    final dataSet = parentContext.read<DataSet>();
    if (dataSet.data.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(parentContext).showSnackBar(
        const SnackBar(content: Text('No data to export')),
      );
      return;
    }

    if (!mounted) return;

    // Store ScaffoldMessengerState before async gap
    final scaffoldMessenger = ScaffoldMessenger.of(parentContext);

    await showDialog(
      context: parentContext,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Export Data'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('CSV'),
              onTap: () async {
                Navigator.pop(dialogContext);
                final success = await _fileService.exportData(dataSet.data, 'csv');
                if (mounted) {
                  _showExportResult(scaffoldMessenger, success);
                }
              },
            ),
            ListTile(
              title: const Text('Excel'),
              onTap: () async {
                Navigator.pop(dialogContext);
                final success = await _fileService.exportData(dataSet.data, 'excel');
                if (mounted) {
                  _showExportResult(scaffoldMessenger, success);
                }
              },
            ),
            ListTile(
              title: const Text('JSON'),
              onTap: () async {
                Navigator.pop(dialogContext);
                final success = await _fileService.exportData(dataSet.data, 'json');
                if (mounted) {
                  _showExportResult(scaffoldMessenger, success);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showExportResult(ScaffoldMessengerState scaffoldMessenger, bool success) {
    scaffoldMessenger.showSnackBar(
      SnackBar(
        content: Text(success ? 'Export successful' : 'Export failed'),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  Future<void> _saveChartAsImage(BuildContext parentContext) async {
    try {
      final RenderRepaintBoundary? boundary = _chartKey.currentContext
          ?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(parentContext).showSnackBar(
          const SnackBar(
            content: Text('No chart available to save'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final ui.Image image = await boundary.toImage(pixelRatio: 3.0);
      final ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);

      if (byteData == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(parentContext).showSnackBar(
          const SnackBar(
            content: Text('Failed to generate chart image'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/chart_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(byteData.buffer.asUint8List());

      // Store Share and ScaffoldMessenger before async gap
      final scaffoldMessenger = ScaffoldMessenger.of(parentContext);

      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Chart Export',
      );

      if (mounted) {
        scaffoldMessenger.showSnackBar(
          const SnackBar(content: Text('Chart ready to share')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(parentContext).showSnackBar(
        SnackBar(
          content: Text('Failed to save chart as image: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}